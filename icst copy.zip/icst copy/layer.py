import torch.nn as nn
import torch
from torch_geometric.nn import GCNConv

from utils import EdgeMatrix


class ATTAINGenerator(nn.Module):
    def __init__(self, config, input_size, graph=None):
        super(ATTAINGenerator, self).__init__()
        self.config = config
        self.conv = nn.Conv2d(in_channels=1, out_channels=1, kernel_size=1)
        self.pool = nn.MaxPool2d(kernel_size=self.config.pool_kernel_size, stride=self.config.pool_kernel_size)
        self.out = nn.Linear(self.config.hidden_size, input_size)

    def forward(self):
        latent_X = torch.rand(size=self.config.latent_X_shape)  # 1*1*128*128
        cnn_out = self.conv(latent_X)  # 1*1*128*128
        output = torch.relu(cnn_out)  # 1*1*128*128
        output = torch.dropout(output, p=self.config.dropout, train=self.training)  # 1*1*128*128
        fake_sample = self.pool(output)  # 1*1*32*64
        fake_sample = fake_sample.squeeze(0)
        fake_sample = self.out(fake_sample)  # 1*32*51
        fake_sample = fake_sample.squeeze(0)  # 32*51
        return fake_sample


class ATTAINDiscriminator(nn.Module):
    def __init__(self, config, input_size):
        super(ATTAINDiscriminator, self).__init__()
        self.config = config
        self.edge_matrix = EdgeMatrix(input_size)
        self.edge_indices = self.edge_matrix.get_all_connected_indices()
        self.gcn_conv = GCNConv(config.batch_size, config.batch_size)
        self.input2hidden = nn.Linear(input_size, config.hidden_size)
        self.out = nn.Linear(input_size, 2)

    def forward(self, data):
        data = data.transpose(0, 1)  # 51* 32
        edges = self.edge_indices
        output = self.gcn_conv(data, edges)  # 51* 32
        output = torch.relu(output)  # 51* 32
        output = output.transpose(0, 1)  # 32*51
        output = self.out(output)
        return output

    def get_hidden(self, x):
        h = torch.zeros(1, x.shape[0], self.config.hidden_size)
        c = torch.zeros(1, x.shape[0], self.config.hidden_size)
        return h, c


class GANGenerator(nn.Module):
    def __init__(self, config, input_size):
        super(GANGenerator, self).__init__()
        self.lstm = nn.LSTM(input_size=config.hidden_size, hidden_size=config.hidden_size, batch_first=True)
        self.linear2d = nn.Linear(config.hidden_size, config.gan_generator_out_size)
        self.config = config
        self.input_size = input_size

    def forward(self, x):
        lstm_out, hidden = self.lstm(self.get_hidden(x), x)
        lstm_out = lstm_out.reshape(-1, self.config.hidden_size)
        logits_2d = self.linear2d(lstm_out)
        output_2d = torch.tanh(logits_2d)
        output_3d = output_2d.reshape(-1, x.shape[0], self.input_size)
        return output_3d

    def get_hidden(self, x):
        h = torch.zeros(x.shape[0], 1, self.config.hidden_size)
        c = torch.zeros(x.shape[0], 1, self.config.hidden_size)
        return h, c


class GANDiscriminator(nn.Module):
    def __init__(self, config):
        super(GANDiscriminator, self).__init__()
        self.lstm = nn.LSTM(input_size=config.hidden_size, hidden_size=config.hidden_size, batch_first=True)
        self.out = nn.Linear(config.hidden_size, config.classification_size)
        self.config = config

    def forward(self, x):
        mean_over_batch = torch.cat([torch.mean(x).unsqueeze(0)] * self.config.batch_size)
        inputs = torch.cat([x, mean_over_batch], dim=2)
        lstm_outputs, lstm_hidden = self.lstm(inputs, self.get_hidden(x))
        logits = torch.einsum(lstm_outputs)
        output = self.out(logits)
        output = torch.sigmoid(output)
        return output, logits

    def get_hidden(self, x):
        h = torch.zeros(x.shape[0], 1, self.config.hidden_size)
        c = torch.zeros(x.shape[0], 1, self.config.hidden_size)
        return h, c
