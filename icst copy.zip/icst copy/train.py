import os

import torch
from torch.nn import CrossEntropyLoss
from tqdm import tqdm
from sklearn.metrics import accuracy_score, precision_score, f1_score, recall_score
import numpy as np
# train loop
from torch.utils.data import DataLoader

from dataset import SWaTDataset, WADIDataset, BATADALDataset
from model import LSTMCNNModel, CUSUMModel, GANModel, ATTAINModel
from settings import Config
import torch.optim as optim
from atpbar import atpbar

from utils import LabelMaker


def train(model, train_loader, evaluate_loader, criterion, optimizer, label_maker, shuffled_train_loader=None):
    """main training loop"""
    # train_iter = tqdm(train_loader)

    best_precision, best_recall, best_f1 = 0.0, 0.0, 0.0
    for epoch_i in range(config.n_epochs):
        if shuffled_train_loader is not None and epoch_i < config.slow_start:
            train_iter = tqdm(shuffled_train_loader)
        else:
            train_iter = tqdm(train_loader)
        for batch_i, train_data in enumerate(train_iter):
            model.zero_grad()
            inputs = train_data["data"]
            labels = label_maker.get_labels(train_data["label"])
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            train_iter.set_postfix({
                "train_loss": loss.item(),
                "best_presicion": best_precision,
                "best_recall": best_recall,
                "best_f1": best_f1
            })
        # evaluation
        precision, recall, f1 = evaluate(model, evaluate_loader, label_maker)
        if f1 > best_f1:
            torch.save(model.state_dict(), os.path.join(config.model_path, "model_F1_{}".format(round(f1, 5))))
        best_precision = max(precision, best_precision)
        best_recall = max(recall, best_recall)
        best_f1 = max(f1, best_f1)


def evaluate(model, evaluate_loader, label_maker):
    all_true_labels = []
    all_predicted_labels = []
    for test_data in evaluate_loader:
        model.zero_grad()
        inputs = test_data["data"]
        labels = labels = label_maker.get_labels(test_data["label"])
        outputs = model(inputs)
        outputs = outputs.detach().numpy()
        labels = labels.detach().numpy()
        predicted_labels = outputs.argmax(1).tolist()
        all_true_labels += list(labels)
        all_predicted_labels += predicted_labels
    # print(sum(all_true_labels))
    # print(sum(all_predicted_labels))
    precision = precision_score(all_true_labels, all_predicted_labels,average="macro")
    recall = recall_score(all_true_labels, all_predicted_labels,average="macro")
    f1 = f1_score(all_true_labels, all_predicted_labels,average="macro")
    return precision, recall, f1

def ground_truth_labeling():
    pass

if __name__ == '__main__':
    config = Config()
    dataset_settings = {
        "swat": {
            "train_dataset": SWaTDataset(config, training=True),
            "test_dataset": SWaTDataset(config, training=False),
        },
        # "wadi": {
        #     "train_dataset": WADIDataset(config, training=True),
        #     "test_dataset": WADIDataset(config, training=False)
        # },
        # "batadal": {
        #     "train_dataset": BATADALDataset(config, training=True),
        #     "test_dataset": BATADALDataset(config, train(False))
        # }
    }
    # train
    train_dataset = dataset_settings["swat"]["train_dataset"]
    test_dataset = dataset_settings["swat"]["test_dataset"]

    train_loader = DataLoader(train_dataset, batch_size=config.batch_size, drop_last=True)
    shuffled_train_loader = DataLoader(train_dataset, batch_size=config.batch_size, drop_last=True, shuffle=False)
    test_loader = DataLoader(test_dataset, batch_size=config.batch_size, drop_last=True)
    # model = LSTMCNNModel(train_dataset.input_size, config)
    # model = CUSUMModel(train_dataset.input_size, config)
    # model = GANModel(train_dataset.input_size, config)
    model = ATTAINModel(config, train_dataset.input_size)
    criterion = CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters())
    label_maker = LabelMaker()
    train(model, train_loader, test_loader, criterion, optimizer, label_maker=label_maker,
          shuffled_train_loader=shuffled_train_loader)
