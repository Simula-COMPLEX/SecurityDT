"""
Author: xuqh
Created on 2020/11/20
"""
import torch.nn as nn
import torch

m = nn.Conv1d(16, 33, 3, stride=2)
input = torch.randn(20, 16, 50)
output = m(input)
print(output.shape)

loss = nn.CrossEntropyLoss()
input = torch.randn(3, 5, requires_grad=True)
target = torch.empty(3, dtype=torch.long).random_(5)
print(input.shape,target.shape)
print(input,target)
output = loss(input, target)
output.backward()
