import pickle

from torch import optim
from torch.nn import CrossEntropyLoss

from model import ATTAINModel
from settings import Config
from train import train


def cross_validation(data, candidates):
    """

    :param data: swat/wadi/batadal
    :param candidates: all possible hyperparameters
    :return: (best_f1,best_parameter)
    """
    length = len(data)
    valid_size = length / 10
    best_f1, best_params = 0.0, None
    for candidate in zip(candidates):
        config.batch_size = candidate.batch_size
        config.hidden_size = candidate.hidden_size
        model = ATTAINModel(config)
        criterion = CrossEntropyLoss()
        optimizer = optim.Adam(model.parameters())
        f1_sum = 0.0
        for i in range(10):
            valid_start = i * valid_size
            valid_end = i * (valid_size) - 1
            valid_set = [data[j] for j in range(len(data)) if valid_start <= j <= valid_end]
            train_set = [data[j] for j in range(len(data)) if valid_start <= j <= valid_end]
            f1 = train(model, train_set, valid_set, criterion, optimizer)
            f1_sum += f1
        f1_avg = f1_sum / 10
        if f1_avg > best_f1:
            best_f1 = f1_avg
            best_params = candidate

    return best_f1, best_params


if __name__ == '__main__':
    config = Config()
    best_f1, best_params = 0.0, None
    data_pkls = [config.swat_valid_pkl_path, config.wadi_valid_pkl_path, config.batadal_valid_pkl_path]
    hyperparameters = {
        "batch_size": [10, 20, 30, 40, 50, 60, 70, 80, 90, 100],
        "hidden_size": [16, 32, 64, 128, 256, 512]
    }

    for data_pkl in data_pkls:
        data = pickle.load(open(data_pkl, "rb"))
        f1, params = cross_validation(data, hyperparameters)
