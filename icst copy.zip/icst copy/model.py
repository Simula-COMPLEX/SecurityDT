import torch.nn as nn
import torch

from layer import ATTAINGenerator, ATTAINDiscriminator, GANGenerator, GANDiscriminator


class LSTMCNNModel(nn.Module):
    def __init__(self, input_size, config):
        super().__init__()
        self.config = config
        self.input_transform = nn.Linear(input_size, config.hidden_size)
        self.lstm = nn.LSTM(input_size=config.hidden_size, hidden_size=config.hidden_size, batch_first=True)
        self.cnn = nn.Conv1d(in_channels=config.hidden_size, out_channels=config.cnn_out_channels,
                             kernel_size=config.cnn_kernel_size)
        self.relu = nn.ReLU()
        self.pooling = nn.MaxPool1d(kernel_size=config.window_size - config.cnn_kernel_size + 1)
        self.output_transform = nn.Linear(config.cnn_out_channels, config.classification_size)

    def forward(self, x):
        x = x.unsqueeze(0)
        hidden_states = self.get_hidden(x)
        inputs = self.input_transform(x)  # batch_size*window_size*hidden_size
        lstm_out, _ = self.lstm(inputs, hidden_states)  # batch_size*window_size*hidden_size
        lstm_out = lstm_out.transpose(1, 2)  # batch_size*hidden_size*window_size
        cnn_out = self.cnn(lstm_out)  # batch_size*output_channel*window_size
        outputs = self.relu(cnn_out)  # batch_size*output_channel*window_size
        outputs = outputs.transpose(1, 2)
        outputs = outputs.squeeze(0)
        outputs = self.output_transform(outputs)
        outputs = torch.tanh(outputs)
        return outputs

    def get_hidden(self, x):
        h = torch.zeros(x.shape[0], 1, self.config.hidden_size)
        c = torch.zeros(x.shape[0], 1, self.config.hidden_size)
        return h, c


class AEModel(nn.Module):
    """Autoencoder model"""

    def __init__(self, input_size, config):
        super().__init__()
        self.encoder_hidden_layer = nn.Linear(
            in_features=input_size, out_features=config.hidden_size
        )
        self.encoder_output_layer = nn.Linear(
            in_features=config.hidden_size, out_features=config.hidden_size
        )
        self.decoder_hidden_layer = nn.Linear(
            in_features=config.hidden_size, out_features=config.hidden_size
        )
        self.decoder_output_layer = nn.Linear(
            in_features=config.hidden_size, out_features=config.classification_size
        )

    def forward(self, features):
        activation = self.encoder_hidden_layer(features)
        activation = torch.relu(activation)
        code = self.encoder_output_layer(activation)
        code = torch.relu(code)
        activation = self.decoder_hidden_layer(code)
        activation = torch.relu(activation)
        activation = self.decoder_output_layer(activation)
        reconstructed = torch.relu(activation)
        return reconstructed


class CUSUMModel(nn.Module):
    def __init__(self, config):
        super(CUSUMModel, self).__init__()
        self.lstm = nn.LSTM(input_size=config.hidden_size, hidden_size=config.hidden_size, batch_first=True)

    def forward(self, x):
        hidden = self.get_hidden(x)
        outputs, hidden = self.lst(hidden, x)
        return outputs

    def get_hidden(self, x):
        h = torch.zeros(x.shape[0], 1, self.config.hidden_size)
        c = torch.zeros(x.shape[0], 1, self.config.hidden_size)
        return h, c


class GANModel(nn.Module):
    def __init__(self):
        super(GANModel, self).__init__()
        self.generator = GANGenerator()
        self.discriminator = GANDiscriminator()

    def forward(self, x):
        real_samples = x
        latent_x = self.get_latent_x()
        fake_samples = self.generator(latent_x)
        likelihood = self.discriminator(real_samples, fake_samples)
        return likelihood, fake_samples

    def get_latent_x(self):
        return torch.rand(self.config.laten_X_shape)


class ATTAINModel(nn.Module):
    def __init__(self, config, input_size):
        super().__init__()
        self.generator = ATTAINGenerator(config, input_size)
        self.discriminator = ATTAINDiscriminator(config, input_size)
        self.config = config

    def forward(self, x):
        real_samples = x
        fake_samples = self.generator()
        likelihood_real = self.discriminator(real_samples)
        likelihood_real = torch.cat([likelihood_real, torch.zeros_like(likelihood_real)], dim=1)

        likelihood_fake = self.discriminator(fake_samples)
        likelihood_fake = torch.cat([torch.zeros_like(likelihood_fake), likelihood_fake], dim=1)
        likelihood = torch.cat([likelihood_real, likelihood_fake], dim=0)
        return likelihood
